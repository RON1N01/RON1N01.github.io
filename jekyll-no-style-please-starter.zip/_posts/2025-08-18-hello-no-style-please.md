---
layout: post
title: Hello, no style, please!
categories: notes
---

First post. Goals: pass Security+, write weekly lab notes, and keep it minimal.
