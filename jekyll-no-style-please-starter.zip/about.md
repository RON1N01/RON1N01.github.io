---
layout: page
title: About
permalink: /about/
---

I'm Daryl. I write concise notes on my cybersecurity learning path (Security+, labs, blue/red team). 
